#include "Arduino.h"
#include "ATParser.h"

ATValue::ATValue(String value)
{
	this->value = value;
}

ATValue::~ATValue(void){
}

String ATValue::toString()
{
	return value;
}